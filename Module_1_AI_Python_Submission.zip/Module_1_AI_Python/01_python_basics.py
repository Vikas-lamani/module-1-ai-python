# Module 1 - Python Basics

name = "Vikas"
age = 18
marks = 85.5

print("Name:", name)
print("Age:", age)
print("Marks:", marks)

number = int(input("Enter a number: "))

if number % 2 == 0:
    print("Even number")
else:
    print("Odd number")

print("Numbers from 1 to 5:")
for i in range(1, 6):
    print(i)
