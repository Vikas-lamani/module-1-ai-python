# Module 1 - Functions and Lists

def square(number):
    return number * number

print("Square:", square(5))

subjects = ["Python", "AI", "Mathematics", "English", "Physics"]

print("Subjects:")
for subject in subjects:
    print(subject)

subjects.append("Machine Learning")
print("Updated list:", subjects)
