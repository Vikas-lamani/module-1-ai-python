# Module 1 - Beginner Practice Programs

# 1. Sum of numbers from 1 to 10
total = 0
for i in range(1, 11):
    total += i
print("Sum:", total)

# 2. Largest of three numbers
a = 10
b = 25
c = 15
largest = max(a, b, c)
print("Largest:", largest)

# 3. Check pass or fail
marks = 55
if marks >= 40:
    print("Pass")
else:
    print("Fail")

# 4. Square using a function
def square(n):
    return n * n

print("Square of 7:", square(7))

# 5. Print a list
items = ["AI", "ML", "Python"]
for item in items:
    print(item)
