# Module 1 — Introduction to AI & Python

This repository completes Module 1 (Day 1–Day 4).

## Topics covered
- Artificial Intelligence (AI)
- Machine Learning (ML)
- Deep Learning (DL)
- Real-world AI applications
- Python basics
- Variables and data types
- Conditions and loops
- Functions
- Lists
- Beginner-friendly Python programs

## Files
- `learning_notes.md` — learning notes
- `01_python_basics.py` — variables, input, conditions and loops
- `02_functions_and_lists.py` — functions and lists
- `03_beginner_programs.py` — simple practice programs
