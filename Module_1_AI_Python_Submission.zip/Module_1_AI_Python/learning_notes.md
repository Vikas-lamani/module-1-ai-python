# Module 1 Learning Notes — Introduction to AI & Python

## Day 1 — Introduction to AI

### What is AI?
Artificial Intelligence is the field of creating computer systems that can perform tasks that normally require human intelligence, such as recognizing patterns, understanding language, making predictions, and solving problems.

### AI vs ML vs Deep Learning
- **AI:** The broad field of making machines behave intelligently.
- **ML:** A part of AI where computers learn patterns from data.
- **Deep Learning:** A part of ML that uses multi-layer neural networks.

Simple relationship:

AI → ML → Deep Learning

### Real-world applications
- Voice assistants
- Recommendation systems
- Face and image recognition
- Spam detection
- Fraud detection
- Self-driving/driver-assistance systems
- Medical image analysis
- Chatbots

## Day 2 — Python Basics

### Variables
A variable stores a value.

```python
name = "Vikas"
age = 18
marks = 85.5
```

### Common data types
- `int` — whole numbers
- `float` — decimal numbers
- `str` — text
- `bool` — True or False

### Input and output
```python
name = input("Enter your name: ")
print("Hello", name)
```

## Day 3 — Conditions, Loops and Lists

### If-else
```python
marks = 70

if marks >= 40:
    print("Pass")
else:
    print("Fail")
```

### For loop
```python
for i in range(1, 6):
    print(i)
```

### While loop
```python
count = 1

while count <= 5:
    print(count)
    count += 1
```

### Lists
```python
subjects = ["Python", "AI", "Math"]
print(subjects[0])
subjects.append("English")
```

## Day 4 — Functions and Practice

### Functions
A function is a reusable block of code.

```python
def greet(name):
    return "Hello " + name

print(greet("Vikas"))
```

### Key takeaways
1. AI is the broad concept of intelligent machines.
2. ML is a subset of AI that learns from data.
3. Deep Learning is a subset of ML using neural networks.
4. Python is beginner-friendly and widely used in AI/ML.
5. Variables store data.
6. Loops repeat code.
7. Functions make code reusable.
8. Lists store multiple values.

## Practice questions
1. Write a program to check whether a number is even or odd.
2. Write a program to find the largest of three numbers.
3. Write a program to calculate the sum of numbers from 1 to 10.
4. Write a function that returns the square of a number.
5. Create a list of five subjects and print each subject.
